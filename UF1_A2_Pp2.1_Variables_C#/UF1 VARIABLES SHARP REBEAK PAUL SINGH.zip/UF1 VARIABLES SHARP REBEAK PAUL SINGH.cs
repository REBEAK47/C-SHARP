using System;
//REBEAK PAUL SINGH SMX2C
class Program
{
    static void Main(string[] args)
    {
        int opcio; // Declaració de la variable per a l'opció seleccionada.
        do
        {
            Console.WriteLine("Selecciona: 1. Suma i producte, 2. Volum cilindre, 3. Equació 2n grau, 0. Sortir");
            opcio = Convert.ToInt32(Console.ReadLine()); // Llegeix l'opció escollida.

            switch (opcio) // Selecciona l'opció corresponent.
            {
                case 1:
                    // Suma i producte
                    Console.Write("Introdueix un número: ");
                    int num1 = Convert.ToInt32(Console.ReadLine()); // Llegeix el primer número.
                    Console.Write("Introdueix un segon número: ");
                    double num2 = Convert.ToDouble(Console.ReadLine()); // Llegeix el segon número.
                    Console.WriteLine($"Suma: {num1 + num2}, Producte: {num1 * num2}"); // Mostra suma i producte.
                    break;

                case 2:
                    // Volum cilindre
                    Console.Write("Radi: ");
                    double radius = Convert.ToDouble(Console.ReadLine()); // Llegeix el radi.
                    Console.Write("Altura: ");
                    double altura = Convert.ToDouble(Console.ReadLine()); // Llegeix l'altura.
                    Console.WriteLine($"Volum: {Math.PI * Math.Pow(radius, 2) * altura}"); // Calcula i mostra el volum.
                    break;

                case 3:
                    // Equació 2n grau
                    Console.Write("Coeficient A: ");
                    double A = Convert.ToDouble(Console.ReadLine()); // Llegeix el coeficient A.
                    Console.Write("Coeficient B: ");
                    double B = Convert.ToDouble(Console.ReadLine()); // Llegeix el coeficient B.
                    Console.Write("Coeficient C: ");
                    double C = Convert.ToDouble(Console.ReadLine()); // Llegeix el coeficient C.
                    double discriminant = Math.Pow(B, 2) - 4 * A * C; // Calcula el discriminant.
                    if (discriminant > 0)
                        Console.WriteLine($"Solucions: {(-B + Math.Sqrt(discriminant)) / (2 * A)}, {(-B - Math.Sqrt(discriminant)) / (2 * A)}"); // Dues solucions reals.
                    else if (discriminant == 0)
                        Console.WriteLine($"Solució doble: {-B / (2 * A)}"); // Solució doble.
                    else
                        Console.WriteLine("No hi ha solucions reals."); // Sense solucions reals.
                    break;

                case 0:
                    Console.WriteLine("Sortint..."); // Missatge de sortida.
                    break;

                default:
                    Console.WriteLine("Opció no vàlida."); // Missatge d'error si l'opció no és vàlida.
                    break;
            }

        } while (opcio != 0); // Repeteix fins que l'usuari esculli sortir.
    }
}
