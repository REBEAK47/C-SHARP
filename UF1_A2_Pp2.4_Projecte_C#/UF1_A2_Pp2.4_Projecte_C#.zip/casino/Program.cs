﻿// REBEAK PAUL SINGH SMX2C EL PROJECTE
using System;

class Casino
{
    static void Main(string[] args)
    {
        double saldo = 100; // Saldo inicial
        bool jugant = true; // Variable per controlar si el jugador segueix jugant

        Console.WriteLine("¡Benvingut al Casino!");
        Console.WriteLine($"El teu saldo inicial és: {saldo}€");

        // Bucle principal del joc
        while (jugant && saldo > 0)
        {
            // Menú d'opcions per al jugador
            Console.WriteLine("\nSelecciona una opció:");
            Console.WriteLine("1. Jugar a la ruleta");
            Console.WriteLine("2. Carreres de cavalls");
            Console.WriteLine("3. Tragaperras");
            Console.WriteLine("4. Sortir del casino");
            Console.Write("Opció: ");

            // Llegir l'opció escollida pel jugador
            string opcio = Console.ReadLine();

            // Segons l'opció triada, s'executa el joc corresponent
            switch (opcio)
            {
                case "1":
                    saldo = JugarRuleta(saldo); // Crida al mètode JugarRuleta i actualitza el saldo
                    break;
                case "2":
                    saldo = CarreresCaballs(saldo); // Crida al mètode CarreresCaballs i actualitza el saldo
                    break;
                case "3":
                    saldo = Tragaperras(saldo); // Crida al mètode Tragaperras i actualitza el saldo
                    break;
                case "4":
                    jugant = false; // Si escull sortir, es canvia la variable per finalitzar el joc
                    break;
                default:
                    Console.WriteLine("Opció no vàlida. Si us plau, prova de nou.");
                    break;
            }

            // Si el saldo és 0 o negatiu, es informa al jugador i es finalitza el joc
            if (saldo <= 0)
            {
                Console.WriteLine("T'has quedat sense saldo. ¡Gràcies per jugar!");
                jugant = false; // Es canvia la variable per sortir del bucle
            }
        }

        // Missatge final mostrant el saldo
        Console.WriteLine($"\nEl teu saldo final és: {saldo}€");
        Console.WriteLine("¡Fins a la propera!");
    }

    // Mètode per jugar a la ruleta
    static double JugarRuleta(double saldo)
    {
        Console.WriteLine("\n¡Benvingut a la ruleta!");
        Console.WriteLine($"Saldo actual: {saldo}€");

        // Sol·licitar al jugador la seva aposta
        Console.Write("Introdueix la teva aposta: ");
        double aposta = Convert.ToDouble(Console.ReadLine());

        // Comprovar si el jugador té suficient saldo per l'aposta
        if (aposta > saldo)
        {
            Console.WriteLine("No tens prou saldo per aquesta aposta.");
            return saldo; // Si no té prou diners, no es modifica el saldo
        }

        // Sol·licitar al jugador a quin número aposta
        Console.Write("Aposta a un número (0-36): ");
        int numeroElegit = Convert.ToInt32(Console.ReadLine());

        Random rnd = new Random();
        int numeroGuanyador = rnd.Next(0, 37); // Número guanyador aleatori entre 0 i 36

        Console.WriteLine($"La ruleta gira... i cau al número {numeroGuanyador}!");

        // Si el jugador encerta, guanya 35 vegades la seva aposta
        if (numeroGuanyador == numeroElegit)
        {
            Console.WriteLine("¡Felicitat! Has guanyat 35 vegades la teva aposta.");
            saldo += aposta * 35;
        }
        else
        {
            // Si no encerta, perd la seva aposta
            Console.WriteLine("Has perdut.");
            saldo -= aposta;
        }

        return saldo; // Retorna el saldo actualitzat
    }

    // Mètode per jugar a les carreres de cavalls
    static double CarreresCaballs(double saldo)
    {
        Console.WriteLine("\n¡Benvingut a les carreres de cavalls!");
        Console.WriteLine($"Saldo actual: {saldo}€");

        // Sol·licitar al jugador la seva aposta
        Console.Write("Introdueix la teva aposta: ");
        double aposta = Convert.ToDouble(Console.ReadLine());

        // Comprovar si el jugador té prou saldo per l'aposta
        if (aposta > saldo)
        {
            Console.WriteLine("No tens prou saldo per aquesta aposta.");
            return saldo; // Si no té prou diners, no es modifica el saldo
        }

        // Sol·licitar al jugador a quin cavall aposta
        Console.Write("Tria un cavall (1-5): ");
        int cavallElegit = Convert.ToInt32(Console.ReadLine());

        Random rnd = new Random();
        int cavallGuanyador = rnd.Next(1, 6); // Cavall guanyador aleatori entre 1 i 5

        Console.WriteLine($"¡La cursa acaba i el cavall guanyador és el {cavallGuanyador}!");

        // Si el jugador tria el cavall guanyador, guanya el doble de la seva aposta
        if (cavallGuanyador == cavallElegit)
        {
            Console.WriteLine("¡Felicitat! Has guanyat el doble de la teva aposta.");
            saldo += aposta * 2;
        }
        else
        {
            // Si no encerta, perd la seva aposta
            Console.WriteLine("Has perdut.");
            saldo -= aposta;
        }

        return saldo; // Retorna el saldo actualitzat
    }

    // Mètode per jugar a les tragaperras
    static double Tragaperras(double saldo)
    {
        Console.WriteLine("\n¡Benvingut a les tragaperras!");
        Console.WriteLine($"Saldo actual: {saldo}€");

        // Sol·licitar al jugador la seva aposta
        Console.Write("Introdueix la teva aposta: ");
        double aposta = Convert.ToDouble(Console.ReadLine());

        // Comprovar si el jugador té prou saldo per l'aposta
        if (aposta > saldo)
        {
            Console.WriteLine("No tens prou saldo per aquesta aposta.");
            return saldo; // Si no té prou diners, no es modifica el saldo
        }

        Random rnd = new Random();
        int simbol1 = rnd.Next(1, 5); // Primer símbol aleatori
        int simbol2 = rnd.Next(1, 5); // Segon símbol aleatori
        int simbol3 = rnd.Next(1, 5); // Tercer símbol aleatori

        Console.WriteLine($"Els rodets giren... {simbol1} | {simbol2} | {simbol3}");

        // Si els tres símbols coincideixen, el jugador guanya 10 vegades la seva aposta
        if (simbol1 == simbol2 && simbol2 == simbol3)
        {
            Console.WriteLine("¡Jackpot! Has guanyat 10 vegades la teva aposta.");
            saldo += aposta * 10;
        }
        // Si dos símbols coincideixen, el jugador guanya el doble de la seva aposta
        else if (simbol1 == simbol2 || simbol2 == simbol3 || simbol1 == simbol3)
        {
            Console.WriteLine("¡Ben fet! Has guanyat el doble de la teva aposta.");
            saldo += aposta * 2;
        }
        else
        {
            // Si no hi ha coincidències, el jugador perd
            Console.WriteLine("Has perdut.");
            saldo -= aposta;
        }

        return saldo; // Retorna el saldo actualitzat
    }
}
