﻿//REBEAK PAUL SINGH SMX2C
using System;

namespace PracticaPP2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcio = 0;

            // Bucle principal per mostrar el menú i permetre seleccionar l'exercici
            do
            {
                Console.WriteLine("Selecciona un exercici (1-4) o introdueix qualsevol altre número per sortir:");
                opcio = int.Parse(Console.ReadLine());

                // Cada opció del menú executa una funció que correspon a l'exercici seleccionat
                switch (opcio)
                {
                    case 1:
                        Exercici1();
                        break;
                    case 2:
                        Exercici2();
                        break;
                    case 3:
                        Exercici3();
                        break;
                    case 4:
                        Exercici4();
                        break;
                    default:
                        Console.WriteLine("Sortint de l'aplicació...");
                        break;
                }
            } while (opcio >= 1 && opcio <= 4);
        }

        // Exercici 1: Generació de 55 números aleatoris, busca el mínim i el màxim
        static void Exercici1()
        {
            // Creació d'un generador de números aleatoris
            Random rnd = new Random();
            int[] numeros = new int[55];

            // Generació i emmagatzematge dels 55 números aleatoris entre 22 i 1559
            for (int i = 0; i < 55; i++)
            {
                numeros[i] = rnd.Next(22, 1560);
            }

            // Inicialitzem els valors mínim i màxim al primer element de l'array
            int minValor = numeros[0];
            int maxValor = numeros[0];

            // Bucle per trobar el valor més petit
            foreach (int num in numeros)
            {
                if (num < minValor) minValor = num;
            }

            // Bucle per trobar el valor més gran
            foreach (int num in numeros)
            {
                if (num > maxValor) maxValor = num;
            }

            // Imprimeix els resultats de la cerca
            Console.WriteLine($"Valor mínim: {minValor}");
            Console.WriteLine($"Valor màxim: {maxValor}");
        }

        // Exercici 2: Càlcul amb una llista de 333 números
        static void Exercici2()
        {
            Random rnd = new Random();
            int[] numeros = new int[333];
            double suma = 0;

            // Generació de 333 números aleatoris i càlcul de la suma per calcular la mitjana
            for (int i = 0; i < 333; i++)
            {
                numeros[i] = rnd.Next(0, 1001); // Rang entre 0 i 1000
                suma += numeros[i];
            }

            // Calcula la mitjana de tots els números generats
            double mitjana = suma / 333;
            Console.WriteLine($"Mitjana: {mitjana}");

            // Comptem quants números de l'array són múltiples de 4
            int multiplesDe4 = 0;
            foreach (int num in numeros)
            {
                if (num % 4 == 0)
                {
                    multiplesDe4++;
                }
            }
            Console.WriteLine($"Múltiples de 4: {multiplesDe4}");

            // Comptem quants números són més grans que la mitjana
            int majorsQueMitjana = 0;
            foreach (int num in numeros)
            {
                if (num > mitjana)
                {
                    majorsQueMitjana++;
                }
            }
            Console.WriteLine($"Nombres més grans que la mitjana: {majorsQueMitjana}");
        }

        // Exercici 3: Comptar vocals en una frase
        static void Exercici3()
        {
            Console.WriteLine("Introdueix una frase:");
            string frase = Console.ReadLine().ToLower();
            int[] compteVocals = new int[5]; // Índexs corresponents a a, e, i, o, u

            // Bucle per comptar cada vocal
            foreach (char c in frase)
            {
                if (c == 'a') compteVocals[0]++;
                else if (c == 'e') compteVocals[1]++;
                else if (c == 'i') compteVocals[2]++;
                else if (c == 'o') compteVocals[3]++;
                else if (c == 'u') compteVocals[4]++;
            }

            // Imprimeix el resultat de comptar les vocals
            Console.WriteLine($"Nombre de vocals - A: {compteVocals[0]}, E: {compteVocals[1]}, I: {compteVocals[2]}, O: {compteVocals[3]}, U: {compteVocals[4]}");
        }

        // Exercici 4: Simulador de caixer automàtic amb funcions
        static void Exercici4()
        {
            // Saldo inicial del caixer per a la simulació
            double saldoActual = 1000;
            Console.WriteLine("Opcions del caixer automàtic:");
            Console.WriteLine("1. Mirar saldo");
            Console.WriteLine("2. Afegir saldo");
            Console.WriteLine("3. Treure saldo");

            int opcio = int.Parse(Console.ReadLine());

            // L'usuari selecciona una opció que es gestiona amb funcions específiques
            switch (opcio)
            {
                case 1:
                    MirarSaldo(saldoActual);
                    break;
                case 2:
                    Console.WriteLine("Quantitat a afegir:");
                    double afegir = double.Parse(Console.ReadLine());
                    saldoActual = AfegirSaldo(saldoActual, afegir);
                    Console.WriteLine($"Saldo actualitzat: {saldoActual}");
                    break;
                case 3:
                    Console.WriteLine("Quantitat a retirar:");
                    double retirar = double.Parse(Console.ReadLine());
                    saldoActual = TreureSaldo(saldoActual, retirar);
                    Console.WriteLine($"Saldo actualitzat: {saldoActual}");
                    break;
                default:
                    Console.WriteLine("Opció no vàlida.");
                    break;
            }
        }

        // Funció per mostrar el saldo actual
        static void MirarSaldo(double saldoActual)
        {
            // Aquesta funció només imprimeix el saldo actual de l'usuari
            Console.WriteLine($"El saldo actual és: {saldoActual}");
        }

        // Funció per afegir saldo al compte
        static double AfegirSaldo(double saldoActual, double quantitat)
        {
            // Aquesta funció augmenta el saldo amb la quantitat indicada i retorna el nou saldo
            saldoActual += quantitat;
            return saldoActual;
        }

        // Funció per retirar saldo del compte
        static double TreureSaldo(double saldoActual, double quantitat)
        {
            // Aquesta funció resta la quantitat del saldo si hi ha prou diners; si no, mostra un missatge d'error
            if (quantitat > saldoActual)
            {
                Console.WriteLine("Saldo insuficient.");
                return saldoActual; // Retorna el saldo sense canvi si no hi ha suficients fons
            }
            saldoActual -= quantitat; // Actualitza el saldo restant
            return saldoActual;
        }
    }
}
