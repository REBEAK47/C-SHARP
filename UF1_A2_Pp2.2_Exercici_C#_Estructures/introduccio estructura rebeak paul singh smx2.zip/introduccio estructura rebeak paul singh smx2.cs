﻿using System;
//rebeak paul singh smx2c
class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Introdueix un número (1-6) per executar l'exercici o 0 per sortir:");
            int opcio = Convert.ToInt32(Console.ReadLine());

            if (opcio == 0) break;

            switch (opcio)
            {
                case 1:
                    Exercici1();
                    break;
                case 2:
                    Exercici2();
                    break;
                case 3:
                    Exercici3();
                    break;
                case 4:
                    Exercici4();
                    break;
                case 5:
                    Exercici5();
                    break;
                default:
                    Console.WriteLine("Opció no vàlida. Intenta de nou.");
                    break;
            }
        }
    }

    static void Exercici1()
    {
        Console.WriteLine("Introdueix un número:");
        int numero = Convert.ToInt32(Console.ReadLine());
        int suma = 0;

        // Utilitzem un bucle for per sumar els números de 13 fins al número introduït
        for (int i = 13; i <= numero; i++)
        {
            suma += i;
        }

        Console.WriteLine($"La suma dels números enters de 13 a {numero} és: {suma}");
    }

    static void Exercici2()
    {
        Console.WriteLine("Introdueix un número:");
        int numero = Convert.ToInt32(Console.ReadLine());
        int parells = 0, imparells = 0, sumaParells = 0, sumaImperells = 0, multiplesDe13 = 0;

        for (int i = 1; i <= numero; i++)
        {
            if (i % 2 == 0)
            {
                parells++;
                sumaParells += i;
            }
            else
            {
                imparells++;
                sumaImperells += i;
            }

            if (i % 13 == 0)
            {
                multiplesDe13++;
            }
        }

        Console.WriteLine($"Números parells: {parells}, Números imparells: {imparells}");
        Console.WriteLine($"Suma de números parells: {sumaParells}, Suma de números imparells: {sumaImperells}");
        Console.WriteLine($"Múltiples de 13: {multiplesDe13}");
    }

    static void Exercici3()
    {
        Random rand = new Random();
        int jugador1 = rand.Next(0, 3); // 0=pedra, 1=paper, 2=tisora
        int jugador2 = rand.Next(0, 3);

        Console.WriteLine($"Jugador 1: {TradueixJugada(jugador1)}");
        Console.WriteLine($"Jugador 2: {TradueixJugada(jugador2)}");

        // Determinar el guanyador
        if (jugador1 == jugador2)
        {
            Console.WriteLine("Empat!");
        }
        else if ((jugador1 == 0 && jugador2 == 2) || (jugador1 == 1 && jugador2 == 0) || (jugador1 == 2 && jugador2 == 1))
        {
            Console.WriteLine("Guanya Jugador 1!");
        }
        else
        {
            Console.WriteLine("Guanya Jugador 2!");
        }
    }

    static string TradueixJugada(int jugada)
    {
        return jugada switch
        {
            0 => "Pedra",
            1 => "Paper",
            2 => "Tisora",
            _ => "Desconegut"
        };
    }

    static void Exercici4()
    {
        double saldo = 1000; // saldo inicial
        while (true)
        {
            Console.WriteLine("Selecciona una opció: 1) Treure efectiu 2) Dipòsit 3) Comprovar saldo 0) Sortir");
            int opcio = Convert.ToInt32(Console.ReadLine());

            if (opcio == 0) break;

            switch (opcio)
            {
                case 1:
                    Console.WriteLine("Introdueix l'import a retirar:");
                    double retirada = Convert.ToDouble(Console.ReadLine());
                    if (retirada <= saldo)
                    {
                        saldo -= retirada;
                        Console.WriteLine($"Retirat: {retirada}. Saldo restant: {saldo}");
                    }
                    else
                    {
                        Console.WriteLine("Saldo insuficient.");
                    }
                    break;

                case 2:
                    Console.WriteLine("Introdueix l'import a dipositar:");
                    double diposit = Convert.ToDouble(Console.ReadLine());
                    saldo += diposit;
                    Console.WriteLine($"Dipositat: {diposit}. Nou saldo: {saldo}");
                    break;

                case 3:
                    Console.WriteLine($"El teu saldo actual és: {saldo}");
                    break;

                default:
                    Console.WriteLine("Opció no vàlida.");
                    break;
            }
        }
    }

    static void Exercici5()
    {
        Console.WriteLine("Introdueix l'edat del client:");
        int edat = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Introdueix els ingressos mensuals en euros:");
        double ingressos = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Té referència de lloguer anterior positiva? (Sí/No):");
        string referencia = Console.ReadLine().ToLower();

        Console.WriteLine("Introdueix el nombre d'infraccions de trànsit greus:");
        int infraccions = Convert.ToInt32(Console.ReadLine());

        // Comprovar les condicions per poder llogar
        if (edat > 21 && edat < 65 && ingressos >= 2500 && referencia == "sí" && infraccions <= 1)
        {
            Console.WriteLine("El client pot llogar l'apartament.");
        }
        else
        {
            Console.WriteLine("El client NO pot llogar l'apartament.");
        }
    }
}
